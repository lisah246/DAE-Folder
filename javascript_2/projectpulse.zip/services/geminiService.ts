import { GoogleGenAI, Type } from "@google/genai";
import { Project, AIAnalysisResult } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const analyzeProjectHealth = async (project: Project): Promise<AIAnalysisResult | null> => {
  const client = getClient();
  if (!client) {
    console.warn("No API Key found for Gemini analysis");
    return null;
  }

  const prompt = `
    Analyze the following technical project and provide a health assessment.
    
    Project Name: ${project.name}
    Description: ${project.description}
    Status: ${project.status}
    Progress: ${project.progress}%
    
    Tasks:
    ${project.tasks.map(t => `- ${t.title} (${t.isCompleted ? 'Completed' : 'Pending'}, Due: ${t.dueDate})`).join('\n')}
    
    Risks:
    ${project.risks.map(r => `- [${r.severity}] ${r.description} (Mitigation: ${r.mitigationPlan || 'None'})`).join('\n')}
    
    Provide a JSON response with:
    1. A short textual summary of the project state.
    2. A calculated health score from 0 to 100 based on progress vs timeline and severity of risks.
    3. A list of 3 specific recommendations to improve project health.
  `;

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                summary: { type: Type.STRING },
                healthScore: { type: Type.NUMBER },
                recommendations: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                }
            },
            required: ["summary", "healthScore", "recommendations"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;
    return JSON.parse(text) as AIAnalysisResult;

  } catch (error) {
    console.error("Error analyzing project with Gemini:", error);
    return null;
  }
};
