import { Project, ProjectStatus, RiskSeverity } from '../types';

const STORAGE_KEY = 'project_pulse_data';

// Initial seed data
const SEED_DATA: Project[] = [
  {
    id: '1',
    name: 'Cloud Migration Alpha',
    description: 'Migrating legacy on-prem services to AWS infrastructure.',
    owner: 'Jane Doe',
    startDate: '2023-10-01',
    endDate: '2024-03-31',
    status: ProjectStatus.IN_PROGRESS,
    progress: 45,
    tasks: [
      { id: 't1', projectId: '1', title: 'Audit legacy servers', isCompleted: true, dueDate: '2023-10-15' },
      { id: 't2', projectId: '1', title: 'Setup VPC', isCompleted: true, dueDate: '2023-11-01' },
      { id: 't3', projectId: '1', title: 'Migrate Database', isCompleted: false, dueDate: '2024-01-15' },
      { id: 't4', projectId: '1', title: 'Cutover DNS', isCompleted: false, dueDate: '2024-03-30' },
    ],
    risks: [
      { id: 'r1', projectId: '1', description: 'Potential downtime during DB migration', severity: RiskSeverity.HIGH, mitigationPlan: 'Run parallel instances' },
      { id: 'r2', projectId: '1', description: 'Budget overruns on EC2 instances', severity: RiskSeverity.MEDIUM }
    ]
  },
  {
    id: '2',
    name: 'Mobile App Refactor',
    description: 'Refactoring the React Native codebase to improve performance.',
    owner: 'John Smith',
    startDate: '2024-01-01',
    endDate: '2024-06-01',
    status: ProjectStatus.AT_RISK,
    progress: 20,
    tasks: [
      { id: 't5', projectId: '2', title: 'Update dependencies', isCompleted: true, dueDate: '2024-01-10' },
      { id: 't6', projectId: '2', title: 'Refactor Navigation', isCompleted: false, dueDate: '2024-02-01' },
    ],
    risks: [
      { id: 'r3', projectId: '2', description: 'Developer churn', severity: RiskSeverity.CRITICAL, mitigationPlan: 'Hire contractors' }
    ]
  }
];

export const getProjects = (): Project[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_DATA));
    return SEED_DATA;
  }
  return JSON.parse(data);
};

export const saveProject = (project: Project): void => {
  const projects = getProjects();
  const index = projects.findIndex(p => p.id === project.id);
  
  // Recalculate progress based on tasks
  const completedTasks = project.tasks.filter(t => t.isCompleted).length;
  const totalTasks = project.tasks.length;
  project.progress = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

  if (index >= 0) {
    projects[index] = project;
  } else {
    projects.push(project);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
};

export const deleteProject = (id: string): void => {
  const projects = getProjects().filter(p => p.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
};

export const getProjectById = (id: string): Project | undefined => {
  return getProjects().find(p => p.id === id);
};
