export enum ProjectStatus {
  PLANNING = 'Planning',
  IN_PROGRESS = 'In Progress',
  ON_HOLD = 'On Hold',
  COMPLETED = 'Completed',
  AT_RISK = 'At Risk'
}

export enum RiskSeverity {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
  CRITICAL = 'Critical'
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  isCompleted: boolean;
  dueDate: string;
}

export interface Risk {
  id: string;
  projectId: string;
  description: string;
  severity: RiskSeverity;
  mitigationPlan?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  owner: string;
  startDate: string;
  endDate: string;
  status: ProjectStatus;
  progress: number; // 0-100 calculated from tasks
  tasks: Task[];
  risks: Risk[];
}

export interface AIAnalysisResult {
  summary: string;
  healthScore: number;
  recommendations: string[];
}