import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProjectById, saveProject, deleteProject } from '../services/storage';
import { Project, Task, Risk, ProjectStatus, RiskSeverity, AIAnalysisResult } from '../types';
import { analyzeProjectHealth } from '../services/geminiService';
import { 
  ArrowLeft, CheckSquare, AlertTriangle, Sparkles, Trash2, Calendar, 
  User, Check, Plus, RefreshCw, X 
} from 'lucide-react';

const generateId = () => Math.random().toString(36).substr(2, 9);

const ProjectDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Tasks & Risk Form States
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDate, setTaskDate] = useState('');
  
  const [riskDesc, setRiskDesc] = useState('');
  const [riskSeverity, setRiskSeverity] = useState<RiskSeverity>(RiskSeverity.MEDIUM);
  const [riskMitigation, setRiskMitigation] = useState('');

  // AI State
  const [analyzing, setAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null);

  useEffect(() => {
    if (id) {
      const p = getProjectById(id);
      if (p) setProject(p);
      else navigate('/projects'); // Redirect if not found
    }
    setLoading(false);
  }, [id, navigate]);

  const handleUpdateProject = (updatedProject: Project) => {
    saveProject(updatedProject);
    setProject({ ...updatedProject });
  };

  // --- Task Handlers ---
  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!project) return;
    const newTask: Task = {
      id: generateId(),
      projectId: project.id,
      title: taskTitle,
      isCompleted: false,
      dueDate: taskDate
    };
    const updated = { ...project, tasks: [...project.tasks, newTask] };
    handleUpdateProject(updated);
    setTaskTitle('');
    setTaskDate('');
  };

  const toggleTask = (taskId: string) => {
    if (!project) return;
    const updatedTasks = project.tasks.map(t => 
      t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t
    );
    handleUpdateProject({ ...project, tasks: updatedTasks });
  };

  const deleteTask = (taskId: string) => {
      if(!project) return;
      const updatedTasks = project.tasks.filter(t => t.id !== taskId);
      handleUpdateProject({ ...project, tasks: updatedTasks});
  }

  // --- Risk Handlers ---
  const addRisk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!project) return;
    const newRisk: Risk = {
      id: generateId(),
      projectId: project.id,
      description: riskDesc,
      severity: riskSeverity,
      mitigationPlan: riskMitigation
    };
    const updated = { ...project, risks: [...project.risks, newRisk] };
    handleUpdateProject(updated);
    setRiskDesc('');
    setRiskMitigation('');
    setRiskSeverity(RiskSeverity.MEDIUM);
  };

  const deleteRisk = (riskId: string) => {
    if(!project) return;
    const updatedRisks = project.risks.filter(r => r.id !== riskId);
    handleUpdateProject({ ...project, risks: updatedRisks});
  }

  // --- Project Handlers ---
  const handleDeleteProject = () => {
    if (confirm('Are you sure you want to delete this project?')) {
      if (project) deleteProject(project.id);
      navigate('/projects');
    }
  };

  const handleStatusChange = (status: string) => {
      if(!project) return;
      handleUpdateProject({...project, status: status as ProjectStatus});
  }

  // --- AI Handler ---
  const runAIAnalysis = async () => {
    if (!project) return;
    setAnalyzing(true);
    setAiResult(null);
    const result = await analyzeProjectHealth(project);
    setAiResult(result);
    setAnalyzing(false);
  };

  if (loading || !project) return <div>Loading...</div>;

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <button onClick={() => navigate('/projects')} className="text-slate-500 hover:text-indigo-600 flex items-center space-x-1 text-sm mb-2">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Projects</span>
          </button>
          <div className="flex items-center gap-3">
             <h1 className="text-3xl font-bold text-slate-800">{project.name}</h1>
             <select 
                value={project.status} 
                onChange={(e) => handleStatusChange(e.target.value)}
                className="text-sm border-slate-300 rounded-md border p-1"
             >
                 {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
             </select>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={runAIAnalysis}
            disabled={analyzing}
            className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors shadow-sm"
          >
            {analyzing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            <span>Analyze with AI</span>
          </button>
          <button 
            onClick={handleDeleteProject}
            className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Details & Tasks */}
        <div className="lg:col-span-2 space-y-8">
            
            {/* Project Info Card */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-semibold text-slate-800 mb-4">Details</h2>
                <div className="space-y-4">
                    <p className="text-slate-600">{project.description}</p>
                    <div className="flex gap-6 text-sm text-slate-500">
                        <div className="flex items-center gap-2">
                            <User className="h-4 w-4" />
                            <span>{project.owner}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>Start: {project.startDate}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="font-semibold">Progress:</span>
                            <div className="w-24 bg-slate-100 rounded-full h-2">
                                <div className="bg-indigo-500 h-2 rounded-full" style={{width: `${project.progress}%`}}></div>
                            </div>
                            <span>{project.progress}%</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Tasks Section */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <CheckSquare className="h-5 w-5 text-indigo-500" />
                    Tasks ({project.tasks.filter(t => t.isCompleted).length}/{project.tasks.length})
                </h2>
                
                <div className="space-y-2 mb-6">
                    {project.tasks.map(task => (
                        <div key={task.id} className="group flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:border-indigo-100 hover:bg-slate-50 transition-colors">
                            <div className="flex items-center space-x-3">
                                <button 
                                    onClick={() => toggleTask(task.id)}
                                    className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${task.isCompleted ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300'}`}
                                >
                                    {task.isCompleted && <Check className="h-3 w-3 text-white" />}
                                </button>
                                <div className={task.isCompleted ? 'line-through text-slate-400' : 'text-slate-700'}>
                                    <p className="font-medium">{task.title}</p>
                                    <p className="text-xs text-slate-400">{task.dueDate ? `Due: ${task.dueDate}` : 'No date'}</p>
                                </div>
                            </div>
                            <button onClick={() => deleteTask(task.id)} className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                <X className="h-4 w-4" />
                            </button>
                        </div>
                    ))}
                    {project.tasks.length === 0 && <p className="text-slate-400 text-sm italic">No tasks added yet.</p>}
                </div>

                <form onSubmit={addTask} className="flex gap-2">
                    <input 
                        type="text" 
                        value={taskTitle}
                        onChange={(e) => setTaskTitle(e.target.value)}
                        placeholder="New task..."
                        className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        required
                    />
                     <input 
                        type="date" 
                        value={taskDate}
                        onChange={(e) => setTaskDate(e.target.value)}
                        className="w-32 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button type="submit" className="bg-slate-900 text-white p-2 rounded-lg hover:bg-slate-800">
                        <Plus className="h-5 w-5" />
                    </button>
                </form>
            </div>
        </div>

        {/* Right Column: Risks & AI */}
        <div className="space-y-8">

            {/* AI Analysis Result */}
            {aiResult && (
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100 shadow-sm relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <Sparkles className="h-24 w-24 text-indigo-600" />
                    </div>
                    <h3 className="text-indigo-900 font-bold text-lg mb-2 flex items-center gap-2">
                        <Sparkles className="h-4 w-4" /> AI Health Check
                    </h3>
                    <div className="flex items-center gap-2 mb-4">
                        <span className="text-sm text-indigo-700">Calculated Health Score:</span>
                        <div className={`text-xl font-bold ${aiResult.healthScore > 70 ? 'text-emerald-600' : aiResult.healthScore > 40 ? 'text-amber-600' : 'text-red-600'}`}>
                            {aiResult.healthScore}/100
                        </div>
                    </div>
                    <p className="text-sm text-slate-700 mb-4 bg-white/50 p-3 rounded-lg">
                        {aiResult.summary}
                    </p>
                    <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase text-indigo-400">Recommendations</p>
                        <ul className="text-sm text-slate-700 space-y-1 list-disc list-inside">
                            {aiResult.recommendations.map((rec, i) => (
                                <li key={i}>{rec}</li>
                            ))}
                        </ul>
                    </div>
                </div>
            )}

            {/* Risks Section */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                 <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-orange-500" />
                    Risks & Issues
                </h2>
                
                <div className="space-y-3 mb-6">
                    {project.risks.map(risk => (
                        <div key={risk.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 relative group">
                            <div className="flex justify-between items-start mb-1">
                                <span className={`text-xs font-bold px-2 py-0.5 rounded uppercase
                                    ${risk.severity === RiskSeverity.CRITICAL ? 'bg-red-200 text-red-900' : 
                                      risk.severity === RiskSeverity.HIGH ? 'bg-orange-200 text-orange-900' : 
                                      risk.severity === RiskSeverity.MEDIUM ? 'bg-yellow-200 text-yellow-900' : 
                                      'bg-blue-200 text-blue-900'}
                                `}>
                                    {risk.severity}
                                </span>
                                <button onClick={() => deleteRisk(risk.id)} className="text-slate-400 hover:text-red-500">
                                    <X className="h-3 w-3" />
                                </button>
                            </div>
                            <p className="text-sm font-medium text-slate-800 mb-1">{risk.description}</p>
                            {risk.mitigationPlan && (
                                <p className="text-xs text-slate-500">
                                    <span className="font-semibold">Mitigation:</span> {risk.mitigationPlan}
                                </p>
                            )}
                        </div>
                    ))}
                     {project.risks.length === 0 && <p className="text-slate-400 text-sm italic">No risks logged.</p>}
                </div>

                <form onSubmit={addRisk} className="space-y-3 pt-3 border-t border-slate-100">
                    <input 
                        type="text" 
                        value={riskDesc}
                        onChange={(e) => setRiskDesc(e.target.value)}
                        placeholder="Risk description..."
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        required
                    />
                    <div className="flex gap-2">
                         <select 
                            value={riskSeverity}
                            onChange={(e) => setRiskSeverity(e.target.value as RiskSeverity)}
                            className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                        >
                            {Object.values(RiskSeverity).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <input 
                            type="text" 
                            value={riskMitigation}
                            onChange={(e) => setRiskMitigation(e.target.value)}
                            placeholder="Mitigation (optional)"
                            className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>
                    <button type="submit" className="w-full bg-slate-100 text-slate-700 font-medium py-2 rounded-lg hover:bg-slate-200 transition-colors text-sm">
                        Add Risk
                    </button>
                </form>
            </div>
        </div>

      </div>
    </div>
  );
};

export default ProjectDetails;