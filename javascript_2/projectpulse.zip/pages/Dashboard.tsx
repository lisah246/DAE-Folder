import React, { useEffect, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { getProjects } from '../services/storage';
import { Project, ProjectStatus, RiskSeverity } from '../types';
import { AlertTriangle, CheckCircle, Clock, TrendingUp } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    setProjects(getProjects());
  }, []);

  // Metrics Calculation
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === ProjectStatus.IN_PROGRESS).length;
  const atRiskProjects = projects.filter(p => p.status === ProjectStatus.AT_RISK).length;
  const completedProjects = projects.filter(p => p.status === ProjectStatus.COMPLETED).length;
  
  const avgProgress = totalProjects > 0 
    ? Math.round(projects.reduce((acc, curr) => acc + curr.progress, 0) / totalProjects)
    : 0;

  // Chart Data Preparation
  const statusData = [
    { name: 'On Track', value: projects.filter(p => p.status === ProjectStatus.IN_PROGRESS).length, color: '#10b981' },
    { name: 'At Risk', value: projects.filter(p => p.status === ProjectStatus.AT_RISK).length, color: '#ef4444' },
    { name: 'Planning', value: projects.filter(p => p.status === ProjectStatus.PLANNING).length, color: '#64748b' },
    { name: 'Completed', value: projects.filter(p => p.status === ProjectStatus.COMPLETED).length, color: '#4f46e5' },
  ].filter(d => d.value > 0);

  const projectProgressData = projects.map(p => ({
    name: p.name.length > 15 ? p.name.substring(0, 15) + '...' : p.name,
    progress: p.progress,
  }));

  const totalRisks = projects.reduce((acc, p) => acc + p.risks.length, 0);
  const highRisks = projects.reduce((acc, p) => acc + p.risks.filter(r => r.severity === RiskSeverity.HIGH || r.severity === RiskSeverity.CRITICAL).length, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Dashboard</h1>
          <p className="text-slate-500">Overview of technical project health and metrics.</p>
        </div>
        <div className="text-sm text-slate-400">
            Last updated: {new Date().toLocaleDateString()}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Avg Progress" 
          value={`${avgProgress}%`} 
          icon={TrendingUp} 
          color="bg-indigo-500" 
        />
        <StatCard 
          title="Active Projects" 
          value={activeProjects} 
          icon={Clock} 
          color="bg-emerald-500" 
        />
        <StatCard 
          title="At Risk" 
          value={atRiskProjects} 
          icon={AlertTriangle} 
          color="bg-red-500" 
        />
        <StatCard 
          title="High Risks" 
          value={highRisks} 
          icon={AlertTriangle} 
          color="bg-orange-500" 
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Project Progress Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-lg font-semibold text-slate-800 mb-4">Project Progress</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={projectProgressData} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} />
                <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    cursor={{fill: '#f1f5f9'}}
                />
                <Bar dataKey="progress" fill="#4f46e5" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Project Status Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-lg font-semibold text-slate-800 mb-4">Status Distribution</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Recent High Risks Table Preview */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100">
            <h3 className="text-lg font-semibold text-slate-800">Critical & High Risks</h3>
        </div>
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-slate-500">
                <thead className="text-xs text-slate-700 uppercase bg-slate-50">
                    <tr>
                        <th className="px-6 py-3">Project</th>
                        <th className="px-6 py-3">Risk Description</th>
                        <th className="px-6 py-3">Severity</th>
                    </tr>
                </thead>
                <tbody>
                    {projects.flatMap(p => p.risks.map(r => ({ ...r, projectName: p.name })))
                        .filter(r => r.severity === RiskSeverity.CRITICAL || r.severity === RiskSeverity.HIGH)
                        .slice(0, 5)
                        .map(r => (
                        <tr key={r.id} className="bg-white border-b hover:bg-slate-50">
                            <td className="px-6 py-4 font-medium text-slate-900">{r.projectName}</td>
                            <td className="px-6 py-4 truncate max-w-xs">{r.description}</td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-semibold
                                    ${r.severity === RiskSeverity.CRITICAL ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800'}
                                `}>
                                    {r.severity}
                                </span>
                            </td>
                        </tr>
                    ))}
                    {projects.flatMap(p => p.risks).filter(r => r.severity === 'High' || r.severity === 'Critical').length === 0 && (
                        <tr>
                            <td colSpan={3} className="px-6 py-4 text-center text-slate-400">No critical risks identified.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ElementType; color: string }> = ({ title, value, icon: Icon, color }) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center space-x-4">
    <div className={`p-3 rounded-lg ${color} bg-opacity-10`}>
      <Icon className={`h-6 w-6 ${color.replace('bg-', 'text-')}`} />
    </div>
    <div>
      <p className="text-sm font-medium text-slate-500">{title}</p>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
    </div>
  </div>
);

export default Dashboard;