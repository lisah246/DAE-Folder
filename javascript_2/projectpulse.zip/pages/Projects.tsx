import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getProjects, saveProject } from '../services/storage';
import { Project, ProjectStatus } from '../types';
import { Plus, ChevronRight, BarChart2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid'; // Actually we will simulate uuid as using external lib might be tricky without package.json, let's allow a simple random string for now or use uuid if environment supports it. I'll write a simple helper.

const generateId = () => Math.random().toString(36).substr(2, 9);

const Projects: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Form State
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectOwner, setNewProjectOwner] = useState('');

  useEffect(() => {
    setProjects(getProjects());
  }, []);

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    const newProject: Project = {
      id: generateId(),
      name: newProjectName,
      description: newProjectDesc,
      owner: newProjectOwner,
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      status: ProjectStatus.PLANNING,
      progress: 0,
      tasks: [],
      risks: []
    };
    saveProject(newProject);
    setProjects(getProjects());
    setIsModalOpen(false);
    // Reset form
    setNewProjectName('');
    setNewProjectDesc('');
    setNewProjectOwner('');
  };

  const getStatusColor = (status: ProjectStatus) => {
    switch (status) {
      case ProjectStatus.COMPLETED: return 'bg-indigo-100 text-indigo-800';
      case ProjectStatus.IN_PROGRESS: return 'bg-emerald-100 text-emerald-800';
      case ProjectStatus.AT_RISK: return 'bg-red-100 text-red-800';
      case ProjectStatus.PLANNING: return 'bg-slate-100 text-slate-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
            <h1 className="text-2xl font-bold text-slate-800">Projects</h1>
            <p className="text-slate-500">Manage technical initiatives and track their lifecycle.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span>New Project</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <div key={project.id} className="bg-white rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow flex flex-col">
            <div className="p-6 flex-1">
              <div className="flex justify-between items-start mb-4">
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(project.status)}`}>
                  {project.status}
                </span>
                <span className="text-sm text-slate-400">{project.progress}%</span>
              </div>
              
              <h3 className="text-lg font-bold text-slate-900 mb-2 line-clamp-1">{project.name}</h3>
              <p className="text-sm text-slate-500 mb-4 line-clamp-2 h-10">{project.description}</p>
              
              <div className="w-full bg-slate-100 rounded-full h-2 mb-4">
                <div 
                  className={`h-2 rounded-full ${project.status === ProjectStatus.AT_RISK ? 'bg-red-500' : 'bg-indigo-500'}`} 
                  style={{ width: `${project.progress}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Owner: {project.owner}</span>
                <span className="flex items-center space-x-1">
                   <BarChart2 className="h-3 w-3" />
                   <span>{project.tasks.length} tasks</span>
                </span>
              </div>
            </div>
            
            <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 rounded-b-xl flex justify-end">
              <Link 
                to={`/projects/${project.id}`} 
                className="text-indigo-600 hover:text-indigo-800 text-sm font-medium flex items-center space-x-1"
              >
                <span>View Details</span>
                <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        ))}

        {projects.length === 0 && (
            <div className="col-span-full py-12 text-center bg-white rounded-xl border border-dashed border-slate-300">
                <p className="text-slate-500">No projects found. Create one to get started.</p>
            </div>
        )}
      </div>

      {/* Add Project Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-lg text-slate-800">Create New Project</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <Plus className="h-6 w-6 transform rotate-45" />
              </button>
            </div>
            <form onSubmit={handleCreateProject} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Project Name</label>
                <input 
                  type="text" 
                  required
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g. Migration Phase 1"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                <textarea 
                  required
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows={3}
                  placeholder="Goals and scope..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Project Owner</label>
                <input 
                  type="text" 
                  required
                  value={newProjectOwner}
                  onChange={(e) => setNewProjectOwner(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g. Jane Doe"
                />
              </div>
              <div className="pt-4 flex justify-end space-x-3">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Create Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Projects;